delete from USERS;
delete from DOCTOR;
delete from PATIENT;

delete from ADMIN;
delete from SUPERVISOR;

delete from BOOTH;
delete from BOOTH_SUPERVISOR;

delete from BOOTH_DOCTORS;
delete from APPOINTMENT;
delete from DRUGS;
delete from VISITS;
delete from VIDEO_CALLS;