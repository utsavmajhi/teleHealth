drop table DOCTOR cascade;
drop table PATIENT cascade;

drop table ADMIN cascade;
drop table SUPERVISOR cascade;

drop table BOOTH cascade;
drop table BOOTH_SUPERVISOR cascade;

drop table BOOTH_DOCTORS cascade;
drop table APPOINTMENT cascade;
drop table DRUGS cascade;
drop table VISITS cascade;
drop table VIDEO_CALLS cascade;